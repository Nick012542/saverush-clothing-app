import React, { createContext, useContext, useState } from "react";

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (product, selectedSize, quantity) => {
    const existingItem = cartItems.find(
      (item) => item.productId === product.productId && item.selectedSize === selectedSize
    );

    if (existingItem) {
      setCartItems(prev =>
        prev.map(item =>
          item.productId === product.productId && item.selectedSize === selectedSize
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      );
    } else {
      setCartItems(prev => [
        ...prev,
        { ...product, selectedSize, quantity }
      ]);
    }
  };

  const removeFromCart = (productId, selectedSize) => {
    setCartItems(prev =>
      prev.filter(item =>
        !(item.productId === productId && item.selectedSize === selectedSize)
      )
    );
  };

const updateQuantity = (productId, selectedSize, newQuantity) => {
  setCartItems(prevItems =>
    prevItems.map(item =>
      item.productId === productId && item.selectedSize === selectedSize
        ? { ...item, quantity: newQuantity }
        : item
    )
  );
};


  return (
    <CartContext.Provider
      value={{ cartItems, addToCart, removeFromCart, updateQuantity }}
    >
      {children}
    </CartContext.Provider>
  );
};
